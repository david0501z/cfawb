package com.github.kr328.clash.service.data.migrations

import androidx.room.migration.Migration

val MIGRATIONS: Array<Migration> = arrayOf()

val LEGACY_MIGRATION = ::migrationFromLegacy