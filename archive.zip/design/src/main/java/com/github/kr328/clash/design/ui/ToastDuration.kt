package com.github.kr328.clash.design.ui

enum class ToastDuration {
    Short, Long, Indefinite
}