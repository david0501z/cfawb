package com.github.kr328.clash.design.model

class ProfilePageState {
    var allUpdating = false
}