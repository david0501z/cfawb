#pragma once

#include <stdint.h>

uint64_t down_scale_traffic(uint64_t value);